/**
 * 
 */
/**
 * @author AndSanGue
 *
 */
module algoDataWPO {
}