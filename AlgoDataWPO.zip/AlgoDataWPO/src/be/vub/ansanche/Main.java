package be.vub.ansanche;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//WPO.vectorPractice();
		//WPO.linkedListPractice();
		ProductsManager demo = new ProductsManager();
		demo.runDemo();
		

	}
	
	

}
