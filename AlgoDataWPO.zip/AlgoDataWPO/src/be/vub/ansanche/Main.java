package be.vub.ansanche;
import be.vub.ansanche.project.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//WPO.vectorPractice();
		//WPO.linkedListPractice();
		GroceryStore demo = new GroceryStore();
		demo.runDemo();
		//WPO.stackPractice();
		//WPO.stackPracticeLL();
		//WPO.queuePractice();
		//WPO.queuePracticeLL();
		//WPO.priorityQueue();
		//WPO.circulaVector();
		//System.out.println("");
		//WPO.circularListPractice();
		//WPO.lltest();
		//WPO.binaryTree();
		//CSVReader.test();
		

	}
	
	

}
