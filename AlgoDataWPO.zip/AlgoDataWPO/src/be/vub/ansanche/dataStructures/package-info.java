/**
 * 
 */
/**
 * @author AndSanGue
 *
 */
package be.vub.ansanche.dataStructures;