package be.vub.ansanche.dataStructures;

import java.util.Comparator;

public abstract class TreeAction
{
	public abstract void run(Tree.TreeNode n);
}

