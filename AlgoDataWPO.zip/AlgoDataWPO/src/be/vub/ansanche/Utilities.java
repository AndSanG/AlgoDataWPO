package be.vub.ansanche;

public class Utilities {
	public static void print(String string) {
		System.out.print(string);
	}
	public static void println(String string) {
		System.out.println(string);
	}

}
